#ifndef MISSION_GENERATOR_H
#define MISSION_GENERATOR_H

#include "QTextStream"

class Mission_Generator
{
public:
	Mission_Generator();
	void Do_Mission();
	void Header(QTextStream &stream, int randomSeed, float startWeather, float forecastWeather, int year, int month, int day, int hour, int minute);
};

#endif // MISSION_GENERATOR_H
